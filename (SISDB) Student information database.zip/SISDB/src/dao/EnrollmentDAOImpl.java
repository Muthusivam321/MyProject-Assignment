package dao;

import entity.Enrollment;
import util.DBUtil;
import java.sql.*;
import java.util.*;

public class EnrollmentDAOImpl implements EnrollmentDAO {
    public void addEnrollment(Enrollment e) {
        try (Connection conn = DBUtil.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("INSERT INTO Enrollments (student_id, course_id, enrollment_date) VALUES (?, ?, ?)");
            ps.setInt(1, e.getStudentId());
            ps.setInt(2, e.getCourseId());
            ps.setString(3, e.getDate());
            ps.executeUpdate();
            System.out.println("Enrollment added.");
        } catch (Exception ex) { ex.printStackTrace(); }
    }

    public List<Enrollment> getAllEnrollments() {
        List<Enrollment> list = new ArrayList<>();
        try (Connection conn = DBUtil.getConnection()) {
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM Enrollments");
            while (rs.next()) {
                list.add(new Enrollment(
                    rs.getInt("enrollment_id"),
                    rs.getInt("student_id"),
                    rs.getInt("course_id"),
                    rs.getString("enrollment_date")
                ));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }
}
