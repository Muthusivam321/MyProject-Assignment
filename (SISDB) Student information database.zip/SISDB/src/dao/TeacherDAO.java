package dao;
import entity.Teacher;
import java.util.List;

public interface TeacherDAO {
    void addTeacher(Teacher teacher);
    void updateTeacher(Teacher teacher);
    void deleteTeacher(int id);
    Teacher getTeacher(int id);
    List<Teacher> getAllTeachers();
}