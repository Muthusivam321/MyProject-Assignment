package dao;

import entity.Payment;
import util.DBUtil;
import java.sql.*;
import java.util.*;

public class PaymentDAOImpl implements PaymentDAO {
    public void addPayment(Payment p) {
        try (Connection conn = DBUtil.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("INSERT INTO Payments (student_id, amount, payment_date) VALUES (?, ?, ?)");
            ps.setInt(1, p.getStudentId());
            ps.setDouble(2, p.getAmount());
            ps.setString(3, p.getDate());
            ps.executeUpdate();
            System.out.println("Payment added.");
        } catch (Exception e) { e.printStackTrace(); }
    }

    public List<Payment> getAllPayments() {
        List<Payment> list = new ArrayList<>();
        try (Connection conn = DBUtil.getConnection()) {
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM Payments");
            while (rs.next()) {
                list.add(new Payment(
                    rs.getInt("payment_id"),
                    rs.getInt("student_id"),
                    rs.getDouble("amount"),
                    rs.getString("payment_date")
                ));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }
}
