package dao;
import entity.Course;
import java.util.List;

public interface CourseDAO {
    void addCourse(Course c);
    void updateCourse(Course c);
    void deleteCourse(int id);
    Course getCourse(int id);
    List<Course> getAllCourses();
}