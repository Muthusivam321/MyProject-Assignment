package dao;
import entity.Payment;
import java.util.List;

public interface PaymentDAO {
    void addPayment(Payment p);
    List<Payment> getAllPayments();
}
