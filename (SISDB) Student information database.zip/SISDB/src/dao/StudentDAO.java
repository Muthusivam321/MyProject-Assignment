package dao;
import entity.Student;
import java.util.List;

public interface StudentDAO {
    void addStudent(Student student);
    void updateStudent(Student student);
    void deleteStudent(int id);
    Student getStudent(int id);
    List<Student> getAllStudents();
}