package main;

import dao.StudentDAO;
import dao.StudentDAOImpl;
import entity.Student;

import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        StudentDAO studentDAO = new StudentDAOImpl();
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("1. Add Student\n2. View All Students\n3. Get Student\n4. Update Student\n5. Delete Student\n6. Exit");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    Student s = new Student();
                    System.out.println("First Name:"); s.setFirstName(sc.next());
                    System.out.println("Last Name:"); s.setLastName(sc.next());
                    System.out.println("DOB (YYYY-MM-DD):"); s.setDob(sc.next());
                    System.out.println("Email:"); s.setEmail(sc.next());
                    System.out.println("Phone:"); s.setPhone(sc.next());
                    studentDAO.addStudent(s);
                    break;
                case 2:
                    List<Student> list = studentDAO.getAllStudents();
                    for (Student stu : list)
                        System.out.println(stu.getId() + " " + stu.getFirstName() + " " + stu.getLastName());
                    break;
                case 3:
                    System.out.println("Enter ID:");
                    Student st = studentDAO.getStudent(sc.nextInt());
                    if (st != null) System.out.println(st.getFirstName() + " " + st.getLastName());
                    else System.out.println("Not Found");
                    break;
                case 4:
                    Student stu = new Student();
                    System.out.println("ID to update:"); stu.setId(sc.nextInt());
                    System.out.println("First Name:"); stu.setFirstName(sc.next());
                    System.out.println("Last Name:"); stu.setLastName(sc.next());
                    System.out.println("DOB:"); stu.setDob(sc.next());
                    System.out.println("Email:"); stu.setEmail(sc.next());
                    System.out.println("Phone:"); stu.setPhone(sc.next());
                    studentDAO.updateStudent(stu);
                    break;
                case 5:
                    System.out.println("ID to delete:");
                    studentDAO.deleteStudent(sc.nextInt());
                    break;
                case 6:
                    System.exit(0);
            }
        }
    }
}
