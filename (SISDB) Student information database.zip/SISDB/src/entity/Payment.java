package entity;
public class Payment {
    private int id;
    private int studentId;
    private double amount;
    private String date;

    public Payment() {}
    public Payment(int id, int studentId, double amount, String date) {
        this.id = id;
        this.studentId = studentId;
        this.amount = amount;
        this.date = date;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getStudentId() { return studentId; }
    public void setStudentId(int studentId) { this.studentId = studentId; }
    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }
    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }
}