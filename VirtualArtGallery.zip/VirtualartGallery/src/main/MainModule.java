package main;

import dao.VirtualArtGalleryImpl;
import entity.Artwork;
import java.util.List;
import java.util.Scanner;

public class MainModule {
    public static void main(String[] args) {
        VirtualArtGalleryImpl service = new VirtualArtGalleryImpl();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- Virtual Art Gallery Menu ---");
            System.out.println("1. Add Artwork");
            System.out.println("2. Search Artwork");
            System.out.println("3. Remove Artwork");
            System.out.println("4. Show User's Favorite Artworks");
            System.out.println("5. Exit");
            System.out.print("Choose: ");
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    sc.nextLine();
                    System.out.print("Title: ");
                    String title = sc.nextLine();
                    System.out.print("Desc: ");
                    String desc = sc.nextLine();
                    System.out.print("Date (yyyy-mm-dd): ");
                    String date = sc.nextLine();
                    System.out.print("Medium: ");
                    String medium = sc.nextLine();
                    System.out.print("ImageURL: ");
                    String url = sc.nextLine();
                    System.out.print("Artist ID: ");
                    int aid = sc.nextInt();
                    Artwork a = new Artwork(0, title, desc, date, medium, url, aid);
                    System.out.println(service.addArtwork(a) ? "Artwork added!" : "Failed.");
                    break;

                case 2:
                    sc.nextLine();
                    System.out.print("Search keyword: ");
                    String key = sc.nextLine();
                    List<Artwork> list = service.searchArtworks(key);
                    list.forEach(art -> System.out.println(art.getTitle() + " by ArtistID: " + art.getArtistId()));
                    break;

                case 3:
                    System.out.print("Enter Artwork ID to remove: ");
                    int id = sc.nextInt();
                    System.out.println(service.removeArtwork(id) ? "Deleted." : "Not found.");
                    break;

                case 4:
                    System.out.print("Enter User ID: ");
                    int uid = sc.nextInt();
                    List<Artwork> favs = service.getUserFavoriteArtworks(uid);
                    favs.forEach(f -> System.out.println(f.getTitle()));
                    break;

                case 5:
                    System.out.println("Goodbye!");
                    System.exit(0);
            }
        }
    }
}
