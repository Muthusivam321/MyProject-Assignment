package exception;

public class ArtworkNotFoundException extends Exception {
    public ArtworkNotFoundException(String message) {
        super(message);
    }
}
