package util;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBConnUtil {
    private static Connection conn;

    public static Connection getConnection() {
        if (conn == null) {
            try {
                Properties props = new Properties();

                // Path to your db.properties file (relative to project root)
                FileInputStream fis = new FileInputStream("db.properties");
                props.load(fis);

                String driver = props.getProperty("db.driver");
                String url = props.getProperty("db.url");
                String user = props.getProperty("db.username");
                String pass = props.getProperty("db.password");

                Class.forName(driver);
                conn = DriverManager.getConnection(url, user, pass);
            } catch (IOException | SQLException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
        return conn;
    }
}
