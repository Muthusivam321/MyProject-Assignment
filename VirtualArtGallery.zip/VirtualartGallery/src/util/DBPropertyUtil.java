package util;
import java.io.FileInputStream;
import java.util.Properties;

public class DBPropertyUtil {
    public static String getPropertyString(String filename) {
        try {
            Properties props = new Properties();
            props.load(new FileInputStream(filename));
            return props.getProperty("url") + " " + props.getProperty("username") + " " + props.getProperty("password");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
