package main;

import dao.OrderProcessor;
import entity.*;
import exception.*;
import java.util.*;

public class MainModule {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        OrderProcessor processor = new OrderProcessor();

        while (true) {
            System.out.println("\n--- Order Management System ---");
            System.out.println("1. Create User");
            System.out.println("2. Create Product (Admin only)");
            System.out.println("3. Create Order");
            System.out.println("4. Cancel Order");
            System.out.println("5. Get All Products");
            System.out.println("6. Get Orders by User");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();
            sc.nextLine(); // Consume newline

            try {
                switch (choice) {
                    case 1: {
                        System.out.print("Enter userId: ");
                        int id = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Enter username: ");
                        String uname = sc.nextLine();
                        System.out.print("Enter password: ");
                        String pass = sc.nextLine();
                        System.out.print("Enter role (Admin/User): ");
                        String role = sc.nextLine();
                        User user = new User(id, uname, pass, role);
                        processor.createUser(user);
                        break;
                    }
                    case 2: {
                        System.out.print("Enter admin userId: ");
                        int uid = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Enter admin name: ");
                        String uname = sc.nextLine();
                        System.out.print("Enter password: ");
                        String pass = sc.nextLine();
                        User admin = new User(uid, uname, pass, "Admin");

                        System.out.print("Enter Product ID: ");
                        int pid = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Enter Product Name: ");
                        String pname = sc.nextLine();
                        System.out.print("Enter Description: ");
                        String desc = sc.nextLine();
                        System.out.print("Enter Price: ");
                        double price = sc.nextDouble();
                        System.out.print("Enter Quantity: ");
                        int qty = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Enter Type (Electronics/Clothing): ");
                        String type = sc.nextLine();

                        Product p = new Product(pid, pname, desc, price, qty, type);
                        processor.createProduct(admin, p);
                        break;
                    }
                    case 3: {
                        System.out.print("Enter userId: ");
                        int uid = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Enter username: ");
                        String uname = sc.nextLine();
                        System.out.print("Enter password: ");
                        String pass = sc.nextLine();
                        User user = new User(uid, uname, pass, "User");

                        List<Product> orderList = new ArrayList<>();
                        while (true) {
                            System.out.print("Enter productId to order (or 0 to finish): ");
                            int pid = sc.nextInt();
                            if (pid == 0) break;
                            sc.nextLine();
                            Product p = new Product(); // basic placeholder
                            p.setProductId(pid);
                            orderList.add(p);
                        }
                        processor.createOrder(user, orderList);
                        break;
                    }
                    case 4: {
                        System.out.print("Enter userId: ");
                        int uid = sc.nextInt();
                        System.out.print("Enter orderId: ");
                        int oid = sc.nextInt();
                        processor.cancelOrder(uid, oid);
                        break;
                    }
                    case 5: {
                        List<Product> products = processor.getAllProducts();
                        for (Product p : products) {
                            System.out.println(p.getProductId() + " | " + p.getProductName() + " | " + p.getType());
                        }
                        break;
                    }
                    case 6: {
                        System.out.print("Enter userId: ");
                        int uid = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Enter username: ");
                        String uname = sc.nextLine();
                        System.out.print("Enter password: ");
                        String pass = sc.nextLine();
                        User user = new User(uid, uname, pass, "User");

                        List<Product> orders = processor.getOrderByUser(user);
                        for (Product p : orders) {
                            System.out.println(p.getProductName() + " - " + p.getType());
                        }
                        break;
                    }
                    case 7: {
                        System.out.println("Exiting... Goodbye!");
                        sc.close();
                        System.exit(0);
                    }
                    default:
                        System.out.println("Invalid choice.");
                }
            } catch (UserNotFoundException | OrderNotFoundException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }
}
