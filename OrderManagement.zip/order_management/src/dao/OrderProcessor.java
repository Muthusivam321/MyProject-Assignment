package dao;

import entity.*;
import exception.*;
import util.DBConnUtil;

import java.sql.*;
import java.util.*;

public class OrderProcessor implements IOrderManagementRepository {

    private Connection conn;

    public OrderProcessor() {
        conn = DBConnUtil.getDBConn("db.properties");
    }

    @Override
    public void createUser(User user) {
        try {
            PreparedStatement ps = conn.prepareStatement("INSERT INTO users VALUES (?, ?, ?, ?)");
            ps.setInt(1, user.getUserId());
            ps.setString(2, user.getUsername());
            ps.setString(3, user.getPassword());
            ps.setString(4, user.getRole());
            ps.executeUpdate();
            System.out.println("User created successfully.");
        } catch (SQLException e) {
            System.out.println("Error creating user: " + e.getMessage());
        }
    }

    @Override
    public void createProduct(User user, Product product) throws UserNotFoundException {
        try {
            if (!user.getRole().equalsIgnoreCase("Admin")) {
                throw new UserNotFoundException("Only admin users can create products.");
            }

            PreparedStatement ps = conn.prepareStatement("INSERT INTO products VALUES (?, ?, ?, ?, ?, ?)");
            ps.setInt(1, product.getProductId());
            ps.setString(2, product.getProductName());
            ps.setString(3, product.getDescription());
            ps.setDouble(4, product.getPrice());
            ps.setInt(5, product.getQuantityInStock());
            ps.setString(6, product.getType());
            ps.executeUpdate();
            System.out.println("Product created successfully.");
        } catch (SQLException e) {
            System.out.println("Error creating product: " + e.getMessage());
        }
    }

    @Override
    public void createOrder(User user, List<Product> products) throws UserNotFoundException {
        try {
            PreparedStatement checkUser = conn.prepareStatement("SELECT * FROM users WHERE user_id = ?");
            checkUser.setInt(1, user.getUserId());
            ResultSet rs = checkUser.executeQuery();
            if (!rs.next()) {
                createUser(user); // Create user if not exists
            }

            PreparedStatement orderStmt = conn.prepareStatement("INSERT INTO orders(user_id) VALUES (?)", Statement.RETURN_GENERATED_KEYS);
            orderStmt.setInt(1, user.getUserId());
            orderStmt.executeUpdate();
            ResultSet keys = orderStmt.getGeneratedKeys();
            int orderId = 0;
            if (keys.next()) {
                orderId = keys.getInt(1);
            }

            PreparedStatement orderItemStmt = conn.prepareStatement("INSERT INTO order_items(order_id, product_id) VALUES (?, ?)");
            for (Product p : products) {
                orderItemStmt.setInt(1, orderId);
                orderItemStmt.setInt(2, p.getProductId());
                orderItemStmt.addBatch();
            }
            orderItemStmt.executeBatch();
            System.out.println("Order created successfully with Order ID: " + orderId);
        } catch (SQLException e) {
            System.out.println("Error creating order: " + e.getMessage());
        }
    }

    @Override
    public void cancelOrder(int userId, int orderId) throws UserNotFoundException, OrderNotFoundException {
        try {
            PreparedStatement checkUser = conn.prepareStatement("SELECT * FROM users WHERE user_id = ?");
            checkUser.setInt(1, userId);
            ResultSet userRs = checkUser.executeQuery();
            if (!userRs.next()) throw new UserNotFoundException("User ID not found");

            PreparedStatement checkOrder = conn.prepareStatement("SELECT * FROM orders WHERE order_id = ?");
            checkOrder.setInt(1, orderId);
            ResultSet orderRs = checkOrder.executeQuery();
            if (!orderRs.next()) throw new OrderNotFoundException("Order ID not found");

            PreparedStatement deleteItems = conn.prepareStatement("DELETE FROM order_items WHERE order_id = ?");
            deleteItems.setInt(1, orderId);
            deleteItems.executeUpdate();

            PreparedStatement deleteOrder = conn.prepareStatement("DELETE FROM orders WHERE order_id = ?");
            deleteOrder.setInt(1, orderId);
            deleteOrder.executeUpdate();

            System.out.println("Order cancelled successfully.");
        } catch (SQLException e) {
            System.out.println("Error cancelling order: " + e.getMessage());
        }
    }

    @Override
    public List<Product> getAllProducts() {
        List<Product> productList = new ArrayList<>();
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM products");
            while (rs.next()) {
                Product p = new Product(
                    rs.getInt("product_id"),
                    rs.getString("product_name"),
                    rs.getString("description"),
                    rs.getDouble("price"),
                    rs.getInt("quantity_in_stock"),
                    rs.getString("type")
                );
                productList.add(p);
            }
        } catch (SQLException e) {
            System.out.println("Error fetching products: " + e.getMessage());
        }
        return productList;
    }

    @Override
    public List<Product> getOrderByUser(User user) throws UserNotFoundException {
        List<Product> products = new ArrayList<>();
        try {
            PreparedStatement checkUser = conn.prepareStatement("SELECT * FROM users WHERE user_id = ?");
            checkUser.setInt(1, user.getUserId());
            ResultSet rsUser = checkUser.executeQuery();
            if (!rsUser.next()) throw new UserNotFoundException("User ID not found");

            String query = "SELECT p.* FROM products p " +
                           "JOIN order_items oi ON p.product_id = oi.product_id " +
                           "JOIN orders o ON o.order_id = oi.order_id " +
                           "WHERE o.user_id = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, user.getUserId());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Product p = new Product(
                    rs.getInt("product_id"),
                    rs.getString("product_name"),
                    rs.getString("description"),
                    rs.getDouble("price"),
                    rs.getInt("quantity_in_stock"),
                    rs.getString("type")
                );
                products.add(p);
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving orders: " + e.getMessage());
        }
        return products;
    }
}
