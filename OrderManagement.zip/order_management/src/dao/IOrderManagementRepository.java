package dao;

import entity.User;
import entity.Product;
import java.util.List;
import exception.UserNotFoundException;
import exception.OrderNotFoundException;

public interface IOrderManagementRepository {

    void createUser(User user);

    void createProduct(User user, Product product) throws UserNotFoundException;

    void createOrder(User user, List<Product> products) throws UserNotFoundException;

    void cancelOrder(int userId, int orderId) throws UserNotFoundException, OrderNotFoundException;

    List<Product> getAllProducts();

    List<Product> getOrderByUser(User user) throws UserNotFoundException;
}
