package util;
import java.io.FileInputStream;
import java.util.Properties;

public class DBPropertyUtil {
    public static String getConnectionString(String fileName) {
        try {
            Properties props = new Properties();
            props.load(new FileInputStream(fileName));
            return props.getProperty("url") + "," + props.getProperty("username") + "," + props.getProperty("password");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
