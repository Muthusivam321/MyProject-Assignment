package dao;
import entity.Enrollment;
import java.util.List;

public interface EnrollmentDAO {
    void addEnrollment(Enrollment e);
    List<Enrollment> getAllEnrollments();
}