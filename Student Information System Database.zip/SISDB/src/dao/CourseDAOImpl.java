package dao;

import entity.Course;
import util.DBUtil;
import java.sql.*;
import java.util.*;

public class CourseDAOImpl implements CourseDAO {
    public void addCourse(Course c) {
        try (Connection conn = DBUtil.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("INSERT INTO Courses (course_name, course_code, teacher_id) VALUES (?, ?, ?)");
            ps.setString(1, c.getName());
            ps.setString(2, c.getCode());
            ps.setInt(3, c.getTeacherId());
            ps.executeUpdate();
            System.out.println("Course added.");
        } catch (Exception e) { e.printStackTrace(); }
    }

    public void updateCourse(Course c) {
        try (Connection conn = DBUtil.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("UPDATE Courses SET course_name=?, course_code=?, teacher_id=? WHERE course_id=?");
            ps.setString(1, c.getName());
            ps.setString(2, c.getCode());
            ps.setInt(3, c.getTeacherId());
            ps.setInt(4, c.getId());
            ps.executeUpdate();
            System.out.println("Course updated.");
        } catch (Exception e) { e.printStackTrace(); }
    }

    public void deleteCourse(int id) {
        try (Connection conn = DBUtil.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("DELETE FROM Courses WHERE course_id=?");
            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("Course deleted.");
        } catch (Exception e) { e.printStackTrace(); }
    }

    public Course getCourse(int id) {
        Course c = null;
        try (Connection conn = DBUtil.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM Courses WHERE course_id=?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                c = new Course(
                    rs.getInt("course_id"),
                    rs.getString("course_name"),
                    rs.getString("course_code"),
                    rs.getInt("teacher_id")
                );
            }
        } catch (Exception e) { e.printStackTrace(); }
        return c;
    }

    public List<Course> getAllCourses() {
        List<Course> list = new ArrayList<>();
        try (Connection conn = DBUtil.getConnection()) {
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM Courses");
            while (rs.next()) {
                list.add(new Course(
                    rs.getInt("course_id"),
                    rs.getString("course_name"),
                    rs.getString("course_code"),
                    rs.getInt("teacher_id")
                ));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }
}