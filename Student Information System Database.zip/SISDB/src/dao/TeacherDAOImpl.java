package dao;

import entity.Teacher;
import util.DBUtil;
import java.sql.*;
import java.util.*;

public class TeacherDAOImpl implements TeacherDAO {
    public void addTeacher(Teacher t) {
        try (Connection conn = DBUtil.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("INSERT INTO Teacher (first_name, last_name, email) VALUES (?, ?, ?)");
            ps.setString(1, t.getFirstName());
            ps.setString(2, t.getLastName());
            ps.setString(3, t.getEmail());
            ps.executeUpdate();
            System.out.println("Teacher added.");
        } catch (Exception e) { e.printStackTrace(); }
    }

    public void updateTeacher(Teacher t) {
        try (Connection conn = DBUtil.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("UPDATE Teacher SET first_name=?, last_name=?, email=? WHERE teacher_id=?");
            ps.setString(1, t.getFirstName());
            ps.setString(2, t.getLastName());
            ps.setString(3, t.getEmail());
            ps.setInt(4, t.getId());
            ps.executeUpdate();
            System.out.println("Teacher updated.");
        } catch (Exception e) { e.printStackTrace(); }
    }

    public void deleteTeacher(int id) {
        try (Connection conn = DBUtil.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("DELETE FROM Teacher WHERE teacher_id=?");
            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("Teacher deleted.");
        } catch (Exception e) { e.printStackTrace(); }
    }

    public Teacher getTeacher(int id) {
        Teacher t = null;
        try (Connection conn = DBUtil.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM Teacher WHERE teacher_id=?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                t = new Teacher(
                    rs.getInt("teacher_id"),
                    rs.getString("first_name"),
                    rs.getString("last_name"),
                    rs.getString("email")
                );
            }
        } catch (Exception e) { e.printStackTrace(); }
        return t;
    }

    public List<Teacher> getAllTeachers() {
        List<Teacher> list = new ArrayList<>();
        try (Connection conn = DBUtil.getConnection()) {
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM Teacher");
            while (rs.next()) {
                list.add(new Teacher(
                    rs.getInt("teacher_id"),
                    rs.getString("first_name"),
                    rs.getString("last_name"),
                    rs.getString("email")
                ));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }
}
