package util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ReportGenerator {
    public static void showEnrollmentReport() {
        try (Connection conn = DBUtil.getConnection()) {
            String sql = "SELECT s.first_name, s.last_name, c.course_name FROM Enrollments e " +
                         "JOIN Students s ON e.student_id = s.student_id " +
                         "JOIN Courses c ON e.course_id = c.course_id";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                System.out.println(rs.getString(1) + " " + rs.getString(2) + " -> " + rs.getString(3));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void showPaymentReport() {
        try (Connection conn = DBUtil.getConnection()) {
            String sql = "SELECT s.first_name, s.last_name, p.amount, p.payment_date FROM Payments p " +
                         "JOIN Students s ON p.student_id = s.student_id";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                System.out.println(rs.getString(1) + " " + rs.getString(2) + ", Paid: $" + rs.getDouble(3) + " on " + rs.getString(4));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
